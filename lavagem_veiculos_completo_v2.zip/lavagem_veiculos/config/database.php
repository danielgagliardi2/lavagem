<?php

// /config/database.php
// Este arquivo será gerado/atualizado pelo script de instalação (/setup/setup.php)

return [
    'host' => 'localhost',       // Host do banco de dados (ex: localhost ou 127.0.0.1)
    'db_name' => 'lavagem_db',   // Nome do banco de dados
    'username' => 'root',        // Usuário do banco de dados
    'password' => ''             // Senha do banco de dados
];

